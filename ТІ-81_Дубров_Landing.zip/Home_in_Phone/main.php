<?php
header('Location: Landing.html');
$page = $_GET['page'] ?? 'landing';
switch ($page) {
    case 'landing':
        header('Location: Landing.html');
        break;
    case 'inform':
        header('Location: Shop_page.html');
        break;
    case 'shop':
        header('Location: Inform_page.html');
        break;
}
