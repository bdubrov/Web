<?php

$name = htmlentities($_POST['name']) ?? '';
$lastname = htmlentities($_POST['lastname']) ?? '';
$phone = htmlentities($_POST['phone']) ?? '';
$email = htmlentities($_POST['email']) ?? '';
echo "name: $name <br> lastname = $lastname <br> phone: $phone <br> email: $email <br>";