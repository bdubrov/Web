<?php

// роботи зі змінними та автоматичне приведення типу змінної
$num = 10;
$name = 'Bohdan';
echo "$name have $num apple <br>";

// демонстрація різниці оператора додавання та оператора конкатенації
$a = 1;
$b = 1000;
$c = 9;
$str = 'aaa';
$str1 = $a + $b + $c;
$str2 = $a . $b . $c;
$str3 = $a . $str;
echo "$str1 != $str2 <br> $str3 <br>";

// звичайне порівняння змінних
$var1 = 2;
$var2 = 2;
if ($var1 > $var2) {
    echo "$var1 > $var2<br>";
} else if ($var1 < $var2) {
    echo "$var1 < $var2<br>";
} else {
    echo "$var1 == $var2<br>";
}

// порівняння змінних різних типів. в цьому випадку змінні будуть приведені до одного типу та порівняні
$var1 = 0;
$var1_s = '0';
if ($var1 == $var1_s) {
    echo "var1 == var1_s <br>";
} else {
    echo "var1 != var1_s <br>";
}

// порівняння змінних перевіряючи і тип і значення
if ($var1 === $var1_s) {
    echo "var1 === var1_s <br>";
} else {
    echo "var1 !== var1_s <br>";
}

$arr = [];
if ($arr) {
    echo "масив arr не порожній<br>";
} else {
    echo "масив arr порожній<br>";
}
$arr1 = [0, 1, 2];
if ($arr1) {
    echo "масив arr1 не порожній<br>";
} else {
    echo "масив arr1 порожній<br>";
}

// хешмасив
$ascii = ['a'=>97,'b'=>98, 'c'=>99, 'd'=>100];

// цикли
$arr2 = ['a', 'b', 'c', 'd'];
for ($i = 0; $i < 4; $i++) {
    echo "$i: $arr2[$i]; ";
}

echo "<br>";

foreach ($arr2 as $i) {
    echo "$i; ";
}

echo "<br>";

foreach ($ascii as $key => $value) {
    echo "$key in ascii $value; ";
}

echo "<br>";

// розіменування
$var = 'value';
$var0 = 'var';
echo $$var0;
echo "<br>";

// implode об'єднує елементи у строку розділюючи один вид одного параметром glue, який за замовченням дорівнює порожній строці
$words = ['1', '2', '3', '4', 'a', 'b', 'c', 'd'];
$string1 = implode(",", $words);
$string0 = implode($words);
echo "$string0<br>$string1<br>";

// explode розділяє рядок на елементи по заданому символу для розділення, повертае масив елементів
$words = explode(',', $string1);
foreach ($words as $a) {
    echo "$a ";
}
echo "<br>";
class Base {
    public $base_var;
    function __construct($base_var) {
        $this->base_var = $base_var;
        echo 'Конструктор базового класу ', $this->base_var, "<br>";
    }
    function __destruct() {
        echo "Деструктор базового класу <br>";
    }
    public function getParam() {
        return $this->base_var;
    }
}
class Derived extends Base {
    public $der_var;

    function __construct($base_var, $der_var) {
        parent::__construct($base_var);
        $this->der_var = $der_var;
        echo 'Конструктор класу нащадка ', $this->der_var, "<br>";
    }
    function __destruct() {
        parent::__destruct();
        echo "Деструктор дочірнього класу <br>";
    }
    public function getSumParam() {
        return $this->der_var + parent::getParam();
    }
}



$baseobj = new Base(10);
echo "Параметр базового класу: ", $baseobj->getParam(), "<br>";

$derobj = new Derived(8, 2);
echo "Параметр батьківського класу для класу нащадка: ", $derobj->getParam(), "<br>";
echo "Параметр класу нащадка: $derobj->der_var <br>";
echo "Сума параметрів базового класу та класу нащадка: ", $derobj->getSumParam(), "<br>";



class Singleton {
    private static $instance;

    private function __construct() { }

    private function __clone() { }

    public static function getInstance(): Singleton {
        if (static::$instance === null) {
            static::$instance = new static();
        }

        return static::$instance;
    }
}

$s1 = Singleton::getInstance();
$s2 = Singleton::getInstance();
if ($s1 === $s2) {
    echo "Об'єкти s1 та s2 - той самий об'єкт<br>";
} else {
    echo "Об'єкти s1 та s2 - різні<br>";
}

